#ifndef XLOCALE_XLOCALE_H
#define XLOCALE_XLOCALE_H

/**
 Fake xlocale support for qnx
 */
#ifdef __cplusplus
extern "C"
{
#endif

#include <qnx_xlocale/qnx_locale.h>

#if __has_include(<ctype.h>)
#include <qnx_xlocale/qnx_ctype_l.h>
#endif

#if __has_include(<wctype.h>)
#include <qnx_xlocale/qnx_wctype_l.h>
#endif

#if __has_include(<inttypes.h>)
#include <qnx_xlocale/qnx_inttypes_l.h>
#endif

#if __has_include(<stdio.h>)
#include <qnx_xlocale/qnx_stdio_l.h>
#endif

#if __has_include(<stdlib.h>)
#include <qnx_xlocale/qnx_stdlib_l.h>
#endif

#if __has_include(<string.h>)
#include <qnx_xlocale/qnx_string_l.h>
#endif

#if __has_include(<time.h>)
#include <qnx_xlocale/qnx_time_l.h>
#endif

#if __has_include(<wchar.h>)
#include <qnx_xlocale/qnx_wchar_l.h>
#endif

#if __has_include(<langinfo.h>)
#include <qnx_xlocale/qnx_langinfo.h>
#endif

#ifdef __cplusplus
}
#endif

#endif // XLOCALE_XLOCALE_H
