# liblocale

Provides FreeBSD locale symbols and maps them to the non-locale version of themselfs.

This is not compatible with QNX `locale.h` when using OSG's LLVM toolchain, you need to remove `locale.h` from the SDP.
