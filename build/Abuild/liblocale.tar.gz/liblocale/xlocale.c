#include "wchar.h"
#include <stdlib.h>
#include <stdio.h>
#include <threads.h>
#include <wctype.h>
#include <stdarg.h>
#include <inttypes.h>
#include <string.h>
#include "qnx_xlocale/qnx_xlocale.h"
#include <wchar.h>

#ifdef __cplusplus
extern "C" {
#endif

struct lconv* localeconv_l(locale_t locale) { return localeconv(); }

locale_t newlocale(int mask, const char* locale, locale_t base)
{
    if(base != (locale_t)0)
    {
        freelocale(base);
    }

    return (locale_t)malloc(sizeof(char)); 
}

void freelocale(locale_t locale) 
{
    free((void*)locale);
}

locale_t uselocale(locale_t locale)
{
    thread_local static locale_t lc = LC_GLOBAL_LOCALE; 

    if (locale == (locale_t)0)
    {
        return lc;
    }

    locale_t tmp = lc;
    lc = locale;
    return tmp;
}

#include <ctype.h>

int isalnum_l(int c, locale_t loc) { return isalnum(c); };
int isalpha_l(int c, locale_t loc) { return isalpha(c); };
int isblank_l(int c, locale_t loc) { return isblank(c); };
int iscntrl_l(int c, locale_t loc) { return iscntrl(c); };
int isdigit_l(int c, locale_t loc) { return isdigit(c); };
int isgraph_l(int c, locale_t loc) { return isgraph(c); };
int ishexnumber_l(int c, locale_t loc) { return isxdigit(c); };
int islower_l(int c, locale_t loc) { return islower(c); };
int isnumber_l(int c, locale_t loc) { return isdigit(c); };
int isprint_l(int c, locale_t loc) { return isprint(c); };
int ispunct_l(int c, locale_t loc) { return ispunct(c); };
int isrune_l(int c, locale_t loc) { return isascii(c); };
int isspace_l(int c, locale_t loc) { return isspace(c); };
int isupper_l(int c, locale_t loc) { return isupper(c); };
int isxdigit_l(int c, locale_t loc) { return isxdigit(c); };
int tolower_l(int c, locale_t loc) { return tolower(c); };
int toupper_l(int c, locale_t loc) { return toupper(c); };

int iswalnum_l(wint_t wc, locale_t loc) { return iswalnum(wc); }
int iswalpha_l(wint_t wc, locale_t loc) { return iswalpha(wc); }
int iswcntrl_l(wint_t wc, locale_t loc) { return iswcntrl(wc); }
int iswctype_l(wint_t wc, wctype_t desc, locale_t loc) { return iswctype(wc, desc); }
int iswdigit_l(wint_t wc, locale_t loc) { return iswdigit(wc); }
int iswgraph_l(wint_t wc, locale_t loc) { return iswgraph(wc); }
int iswlower_l(wint_t wc, locale_t loc) { return iswlower(wc); }
int iswprint_l(wint_t wc, locale_t loc) { return iswprint(wc); }
int iswpunct_l(wint_t wc, locale_t loc) { return iswpunct(wc); }
int iswspace_l(wint_t wc, locale_t loc) { return iswspace(wc); }
int iswupper_l(wint_t wc, locale_t loc) { return iswupper(wc); }
int iswxdigit_l(wint_t wc, locale_t loc) { return iswxdigit(wc); }
int iswblank_l(wint_t wc, locale_t loc) { return iswblank(wc); }
int iswhexnumber_l(wint_t wc, locale_t loc) { return iswxdigit(wc); }
int iswnumber_l(wint_t wc, locale_t loc) { return iswdigit(wc); }
int iswrune_l(wint_t wc, locale_t loc) { return isascii(wc); }
wint_t towlower_l(wint_t wc, locale_t loc) { return towlower(wc); }
wint_t towupper_l(wint_t wc, locale_t loc) { return towupper(wc); }
wint_t towctrans_l(wint_t wc, wctrans_t desc, locale_t loc) { return towctrans(wc, desc); };
wctype_t wctype_l(const char * property, locale_t loc) { return wctype(property); };
wctrans_t wctrans_l(const char* charclass, locale_t loc) { return wctrans(charclass); };

intmax_t strtoimax_l(const char* __restrict __s, char** __restrict __endptr, int __base, locale_t locale) 
{ return strtoimax(__s, __endptr, __base); } 
intmax_t wcstoimax_l(const wchar_t* __restrict s, wchar_t** __restrict __endptr, int __base, locale_t locale) 
{return wcstoimax(s, __endptr, __base); }
uintmax_t strtoumax_l(const char* __restrict __s, char** __restrict __endptr, int __base, locale_t locale) 
{return strtoumax(__s, __endptr, __base); }
uintmax_t wcstoumax_l(const wchar_t* __restrict s, wchar_t** __restrict __endptr, int __base, locale_t locale) 
{return wcstoumax(s, __endptr, __base); }

#include "qnx_xlocale/qnx_stdio_l.h"
int printf_l(locale_t loc, const char* format, ...) 
{ va_list ap; va_start(ap, format); int r = vprintf_l(loc, format, ap); va_end(ap); return r;}
int asprintf_l(char** ret, locale_t loc, const char* format, ...) 
{ va_list ap; va_start(ap, format); int r = vasprintf_l(ret, loc, format, ap); va_end(ap); return r; }
int fprintf_l(FILE* stream, locale_t loc, const char* format, ...) 
{ va_list ap; va_start(ap, format); int r = vfprintf_l(stream, loc, format, ap); va_end(ap); return r; }
int snprintf_l(char* str, size_t size, locale_t loc, const char* format, ...) 
{ va_list ap; va_start(ap, format); int r = vsnprintf_l(str, size, loc, format, ap); va_end(ap); return r; }
int sprintf_l(char* str, locale_t loc, const char* format, ...) 
{ va_list ap; va_start(ap, format); int r = vsprintf_l(str, loc, format, ap); va_end(ap); return r; }

int vasprintf_l(char** ret, locale_t loc, const char* format, va_list ap) 
{ return vasprintf(ret, format, ap); }
int vfprintf_l(FILE* stream, locale_t loc, const char* format, va_list ap) 
{ return vfprintf(stream, format, ap); }
int vprintf_l(locale_t loc, const char* format, va_list ap) 
{ return vprintf(format, ap); }
int vsnprintf_l(char* str, size_t size, locale_t loc, const char* format, va_list ap) 
{ return vsnprintf(str, size, format, ap); }
int vsprintf_l(char* str, locale_t loc, const char* format, va_list ap) 
{ return vsprintf(str, format, ap); }

int scanf_l(locale_t loc, const char* format, ...) 
{ va_list ap; va_start(ap, format); int r = vscanf_l(loc, format, ap); va_end(ap); return r; }
int fscanf_l(FILE* stream, locale_t loc, const char* format, ...) 
{ va_list ap; va_start(ap, format); int r = vfscanf_l(stream, loc, format, ap); va_end(ap); return r; }
int sscanf_l(const char* str, locale_t loc, const char* format, ...) 
{ va_list ap; va_start(ap, format); int r = vsscanf_l(str, loc, format, ap); va_end(ap); return r; }
int vfscanf_l(FILE* stream, locale_t loc, const char* format, va_list ap) 
{ return vfscanf(stream, format, ap); }
int vscanf_l(locale_t loc, const char* format, va_list ap) 
{ return vscanf(format, ap); }
int vsscanf_l(const char* str, locale_t loc, const char* format, va_list ap) 
{ return vsscanf(str, format, ap); }

double atof_l(const char* nptr, locale_t loc) {return atof(nptr);}
int atoi_l(const char* nptr, locale_t loc) {return atoi(nptr);}
long atol_l(const char* nptr, locale_t loc) {return atol(nptr);}
long long atoll_l(const char* nptr, locale_t loc) {return atoll(nptr);}

int mblen_l(const char* mbchar, size_t nbytes, locale_t locale) 
{ return mblen(mbchar, nbytes); }
size_t mbstowcs_l(wchar_t* wcstring, const char* mbstring, size_t nwchars, locale_t locale) 
{ return mbstowcs(wcstring,mbstring, nwchars); }
int mbtowc_l(wchar_t* wcharp, const char* mbchar, size_t nbytes, locale_t locale) 
{ return mbtowc(wcharp, mbchar, nbytes); }

float strtof_l(const char* __restrict nptr, char** __restrict endptr, locale_t locale) 
{ return strtof(nptr, endptr); }
double strtod_l(const char* __restrict nptr, char** __restrict endptr, locale_t locale) 
{ return strtod(nptr, endptr); }
long double strtold_l(const char* __restrict nptr, char** __restrict endptr, locale_t locale) 
{ return strtold(nptr, endptr); }

long strtol_l(const char* __restrict nptr, char** __restrict endptr, int base, locale_t locale) 
{ return strtol(nptr, endptr, base); }
long long strtoll_l(const char* __restrict nptr, char** __restrict endptr, int base, locale_t locale) 
{ return strtoll(nptr, endptr, base); }
unsigned long strtoul_l(const char* __restrict nptr, char** __restrict endptr, int base, locale_t locale) 
{ return strtoul(nptr, endptr, base); }
unsigned long long strtoull_l(const char* __restrict nptr, char** __restrict endptr, int base, locale_t locale) 
{ return strtoull(nptr, endptr, base); }

int wctomb_l(char* mbchar, wchar_t wchar, locale_t locale) 
{ return wctomb(mbchar, wchar); }
size_t wcstombs_l(char* mbstring, const wchar_t* wcstring, size_t nbytes, locale_t locale) 
{ return wcstombs(mbstring, wcstring, nbytes); }

int strcoll_l(const char* s1, const char* s2, locale_t locale) { return strcoll(s1, s2); }
size_t strxfrm_l(char* dst, const char* src, size_t n, locale_t loc) {return strxfrm(dst, src, n); }
int strcasecmp_l(const char* s1, const char* s2, locale_t locale) {return strcasecmp(s1, s2); }
int strncasecmp_l(const char* s1, const char* s2, size_t len, locale_t locale) {return strncasecmp(s1, s2, len); }
char* strcasestr_l(const char* big, const char* little, locale_t loc) {return strcasestr(big, little); }

size_t strftime_l(char* buf, size_t maxsize, const char* format, const struct tm* timeptr, locale_t locale)
{return strftime(buf, maxsize, format, timeptr);}
char* strptime_l(const char* buf, const char* format, struct tm* timeptr, locale_t loc)
{return strptime(buf, format, timeptr);}

wint_t btowc_l(int c, locale_t loc) { return btowc(c); }
int wctob_l(wint_t c, locale_t loc) { return wctob(c); }

wint_t fgetwc_l(FILE* stream, locale_t locale) { return fgetwc(stream); }
wint_t getwc_l(FILE* stream, locale_t locale) { return getwc(stream); }
wint_t getwchar_l(locale_t locale) { return getwchar(); }
wchar_t* fgetws_l(wchar_t* __restrict ws, int n, FILE* __restrict fp, locale_t locale)
{ return fgetws(ws, n, fp); }

wint_t fputwc_l(wchar_t wc, FILE* stream, locale_t locale) { return fputwc(wc, stream); }
wint_t putwc_l(wchar_t wc, FILE* stream, locale_t locale) { return putwc(wc, stream); }
wint_t putwchar_l(wchar_t wc, locale_t locale) { return putwchar(wc); }

int vfwprintf_l(FILE* __restrict stream, locale_t loc, const wchar_t* __restrict format, va_list ap)
{ return vfwprintf(stream, format, ap); }
int vswprintf_l(wchar_t* __restrict ws, size_t n, locale_t loc, const wchar_t* __restrict format, va_list ap)
{ return vswprintf(ws, n, format, ap);}
int vwprintf_l(locale_t loc, const wchar_t* __restrict format, va_list ap) 
{ return vwprintf(format, ap); }
int fwprintf_l(FILE* __restrict stream, locale_t loc, const wchar_t* __restrict format, ...)
{ va_list ap; va_start(ap, format); int r = vfwprintf_l(stream, loc, format, ap); va_end(ap); return r; }
int swprintf_l(wchar_t* __restrict ws, size_t n, locale_t loc, const wchar_t* __restrict format, ...)
{ va_list ap; va_start(ap, format); int r = vswprintf_l(ws, n, loc, format, ap); va_end(ap); return r; }
int wprintf_l(locale_t loc, const wchar_t* __restrict format, ...)
{ va_list ap; va_start(ap, format); int r = vwprintf_l(loc, format, ap); va_end(ap); return r; }

int vwscanf_l(locale_t loc, const wchar_t* __restrict format, va_list ap)
{ return vwscanf(format, ap); }
int vswscanf_l(const wchar_t* __restrict str, locale_t loc, const wchar_t* __restrict format, va_list ap)
{ return vswscanf(str, format, ap); }
int vfwscanf_l(FILE* __restrict stream, locale_t loc, const wchar_t* __restrict format, va_list ap)
{ return vfwscanf(stream, format, ap); }
int wscanf_l(locale_t loc, const wchar_t* __restrict format, ...)
{ va_list ap; va_start(ap, format); int r = vwscanf_l(loc, format, ap); va_end(ap); return r; }
int fwscanf_l(FILE* __restrict stream, locale_t loc, const wchar_t* __restrict format, ...)
{ va_list ap; va_start(ap, format); int r = vfwscanf_l(stream, loc, format, ap); va_end(ap); return r; }
int swscanf_l(const wchar_t* __restrict str, locale_t loc, const wchar_t* __restrict format, ...)
{ va_list ap; va_start(ap, format); int r = vswscanf_l(str, loc, format, ap); va_end(ap); return r; }

#include "qnx_xlocale/qnx_wchar_l.h"
size_t mbrlen_l(const char* __restrict s, size_t n, mbstate_t* __restrict ps, locale_t locale)
{ return mbrlen(s, n, ps); }
size_t mbrtowc_l(wchar_t* __restrict pc, const char* __restrict s, size_t n, mbstate_t* __restrict ps, locale_t locale)
{ return mbrtowc(pc, s, n, ps); }
size_t mbrtoc16_l(char16_t* __restrict pc, const char* __restrict s, size_t n, mbstate_t* __restrict ps,
                  locale_t locale)
{ return mbrtoc16(pc, s, n, ps); }
size_t mbrtoc32_l(char32_t* __restrict pc, const char* __restrict s, size_t n, mbstate_t* __restrict ps,
                  locale_t locale)
{ return mbrtoc32(pc, s, n, ps); }

int mbsinit_l(const mbstate_t* ps, locale_t locale) { return mbsinit(ps); }

size_t mbsrtowcs_l(wchar_t* __restrict dst, const char** __restrict src, size_t len, mbstate_t* __restrict ps,
                   locale_t locale)
{ return mbsrtowcs(dst, src, len, ps); }

wint_t ungetwc_l(wint_t wc, FILE* stream, locale_t locale)
{ return ungetwc(wc, stream); }

size_t wcrtomb_l(char* __restrict s, wchar_t c, mbstate_t* __restrict ps, locale_t locale)
{ return wcrtomb(s, c, ps); }
size_t c16rtomb_l(char* __restrict s, char16_t c, mbstate_t* __restrict ps, locale_t locale)
{ return c16rtomb(s, c, ps); }
size_t c32rtomb_l(char* __restrict s, char32_t c, mbstate_t* __restrict ps, locale_t locale)
{ return c32rtomb(s, c, ps); }

int wcscoll_l(const wchar_t* s1, const wchar_t* s2, locale_t locale)
{ return wcscoll(s1, s2); }

size_t wcsftime_l(wchar_t* __restrict wcs, size_t maxsize, const wchar_t* __restrict format,
                  const struct tm* __restrict timeptr, locale_t locale)
{ return wcsftime(wcs, maxsize,format,timeptr); }

size_t wcsrtombs_l(char* __restrict dst, const wchar_t** __restrict src, size_t len, mbstate_t* __restrict ps,
                   locale_t locale)
{ return wcsrtombs(dst, src, len, ps); }

float wcstof_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, locale_t locale)
{ return wcstof(nptr, endptr); }
long double wcstold_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, locale_t locale)
{ return wcstold(nptr, endptr); }
double wcstod_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, locale_t locale)
{ return wcstod(nptr, endptr); }

long wcstol_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, int base, locale_t locale)
{ return wcstol(nptr, endptr, base); }
unsigned long wcstoul_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, int base, locale_t locale)
{ return wcstoul(nptr, endptr, base); }
long long wcstoll_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, int base, locale_t locale)
{ return wcstoll(nptr, endptr, base); }
unsigned long long wcstoull_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, int base, locale_t locale)
{ return wcstoull(nptr, endptr, base); }

size_t wcsxfrm_l(wchar_t* __restrict dst, const wchar_t* __restrict src, size_t n, locale_t locale)
{ return wcsxfrm(dst, src, n); }

int wcwidth_l(wchar_t wc, locale_t locale)
{ return wcwidth(wc); }

size_t mbsnrtowcs_l(wchar_t* __restrict dst, const char** __restrict src, size_t nms, size_t len,
                    mbstate_t* __restrict ps, locale_t locale)
{ return mbsnrtowcs(dst, src, nms, len, ps); }
size_t wcsnrtombs_l(char* __restrict dst, const wchar_t** __restrict src, size_t nwc, size_t len,
                    mbstate_t* __restrict ps, locale_t locale)
{ return wcsnrtombs(dst, src, nwc, len, ps); }
int wcswidth_l(const wchar_t* pwcs, size_t n, locale_t locale)
{ return wcswidth(pwcs, n); }

#include <limits.h>
#include <errno.h>
size_t mbsnrtowcs(wchar_t *dst, const char **src, size_t nmc, size_t nwc, mbstate_t *ps) 
{
  size_t i;
  const char *s = *src;

  if (!dst) {
    nwc = (size_t)-1;
  }

  for (i=0; i < nwc && nmc != 0; ++i) {
    wchar_t wc;
    const int len = mbrtowc(&wc, s, nmc, ps);
    if (len < 0) {
      return -1;
    }

    s += len;
    nmc -= len;
    if (dst) {
      dst[i] = wc;
      *src = s;
    }
    if (len == 0) {
      if (dst) {
        *src = NULL;
      }
      break;
    }
  }
  return i;
}

size_t wcsnrtombs(char *dst, const wchar_t **src, size_t nwc, size_t nmc, mbstate_t *ps) 
{
  size_t nbytes = 0;
  size_t i;
  const wchar_t *const ws = *src;

  if (!dst) {
    nmc = (size_t)-1;
  }

  for (i=0; i < nwc && nmc > nbytes; ++i) {
    char buf[MB_LEN_MAX];
    const int len = wcrtomb(buf, ws[i], ps);
    if (len == -1) {
        return -1;
    }
    if ((nbytes+=len) > nmc) {
        errno = EILSEQ;
        return -1;
    }
    if (dst) {
      memcpy(dst, buf, len);
      dst += len;
      *src = &ws[i+1];
    }
    if (ws[i] == L'\0') {
      if (dst) {
        *src = NULL;
      }
      nbytes--;
      break;
    }
  }
  EL2HLT;
  return nbytes;
}

int wcswidth(const wchar_t *pwcs, size_t n)
{
    int w, width = 0;

    for (;*pwcs && n-- > 0; pwcs++)
    {
        if ((w = wcwidth(*pwcs)) < 0)
        {
            return -1;
        }
        else
        {
            width += w;
        }
    }

  return width;
}

#include "qnx_xlocale/qnx_langinfo.h"
char* nl_langinfo_l(nl_item item, locale_t loc)
{
    return nl_langinfo(item);
}

#ifdef __cplusplus
}
#endif