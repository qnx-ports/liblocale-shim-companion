#ifndef LIBLOCALE_WCHAR_H
#define LIBLOCALE_WCHAR_H

#ifndef __PLATFORM_H_INCLUDED
#include <sys/platform.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#include_next <wchar.h>

size_t mbsnrtowcs(wchar_t *dst, const char **src, size_t nmc, size_t nwc, mbstate_t *ps);
size_t wcsnrtombs(char *dst, const wchar_t **src, size_t nwc, size_t nmc, mbstate_t *ps);
int wcswidth(const wchar_t *pwcs, size_t n);

#ifdef __cplusplus
}
#endif

#endif // LIBLOCALE_WCHAR_H
