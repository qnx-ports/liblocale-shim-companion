#ifndef LIBLOCALE_STRINGS_H
#define LIBLOCALE_STRINGS_H

#ifdef __cplusplus
extern "C" {
#endif

#include_next <strings.h>

#define bzero(dst, n) memset((dst), 0x0, (n))
#define bcopy(src, dst, n) memmove((dst), (src), (n))

#ifdef __cplusplus
}
#endif

#endif // LIBLOCALE_STRINGS_H
