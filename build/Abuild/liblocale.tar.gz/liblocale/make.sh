#!/bin/bash

if [[ $1 == "clean" ]]; then
    rm liblocale.c.o
    rm liblocale.a
    rm liblocale.so
    exit 0
fi

$CC -c xlocale.c -fPIC -O2 -o liblocale.c.o
$CC -shared xlocale.c -fPIC -O2 -o liblocale.so
ar rcs liblocale.a liblocale.c.o
