#ifndef XLOCALE_LOCALE_H
#define XLOCALE_LOCALE_H

/**
 Fake locale support for qnx
 */
#ifdef __cplusplus
extern "C"
{
#endif

#include <qnx_xlocale/qnx_locale.h>

#ifdef __cplusplus
}
#endif

#endif // XLOCALE_LOCALE_H
