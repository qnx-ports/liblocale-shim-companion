#!/bin/bash

if [[ $1 == "uninstall" ]]; then
    rm -rf $PREFIX/include/shims/wchar.h
    rm -rf $PREFIX/include/shims/strings.h
    rm -rf $PREFIX/include/shims/locale.h
    rm -rf $PREFIX/include/shims/xlocale.h 
    rm -rf $PREFIX/include/shims/qnx_xlocale
    rm -rf $PREFIX/lib/liblocale.a
    rm -rf $PREFIX/lib/liblocale.so
    exit 0
fi

# install 

if ! [[ -d $PREFIX/include ]]; then
    mkdir -p $PREFIX/include/shims
fi

if ! [[ -d $PREFIX/lib ]]; then
    mkdir -p $PREFIX/lib
fi

cp -rf wchar.h $PREFIX/include/shims
cp -rf strings.h $PREFIX/include/shims
cp -rf locale.h $PREFIX/include/shims
cp -rf xlocale.h $PREFIX/include/shims
cp -rf qnx_xlocale $PREFIX/include/shims
cp -rf liblocale.a $PREFIX/lib
cp -rf liblocale.so $PREFIX/lib
