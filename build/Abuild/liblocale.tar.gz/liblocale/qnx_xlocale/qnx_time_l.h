#ifndef QNX_XLOCALE_TIME_H
#define QNX_XLOCALE_TIME_H

#include <time.h>
#include "qnx_xlocale.h"

#ifdef __cplusplus
extern "C" {
#endif

size_t strftime_l(char* buf, size_t maxsize, const char* format, const struct tm* timeptr, locale_t locale);
char* strptime_l(const char* buf, const char* format, struct tm* timeptr, locale_t loc);

#ifdef __cplusplus
}
#endif

#endif // QNX_XLOCALE_TIME_H
