#ifndef QNX_XLOCALE_QNX_LANGINFO_H
#define QNX_XLOCALE_QNX_LANGINFO_H

#include <langinfo.h>
#include "qnx_xlocale.h"

#ifdef __cplusplus
extern "C" {
#endif

// <langinfo.h>
char* nl_langinfo_l(nl_item item, locale_t loc);

#ifdef __cplusplus
}
#endif

#endif // QNX_XLOCALE_QNX_LANGINFO_H
