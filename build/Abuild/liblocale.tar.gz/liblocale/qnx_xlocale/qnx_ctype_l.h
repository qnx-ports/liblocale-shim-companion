#ifndef QNX_XLOCALE_CTYPE_H
#define QNX_XLOCALE_CTYPE_H

#include "qnx_xlocale.h"

#ifdef __cplusplus
extern "C" {
#endif

int isalnum_l(int c, locale_t loc);
int isalpha_l(int c, locale_t loc);
int isblank_l(int c, locale_t loc);
int iscntrl_l(int c, locale_t loc);
int isdigit_l(int c, locale_t loc);
int isgraph_l(int c, locale_t loc);
int ishexnumber_l(int c, locale_t loc);
int islower_l(int c, locale_t loc);
int isnumber_l(int c, locale_t loc);
int isprint_l(int c, locale_t loc);
int ispunct_l(int c, locale_t loc);
int isrune_l(int c, locale_t loc); // alias of isacii()
int isspace_l(int c, locale_t loc);
int isupper_l(int c, locale_t loc);
int isxdigit_l(int c, locale_t loc);
int tolower_l(int c, locale_t loc);
int toupper_l(int c, locale_t loc);

// Unsupported on QNX
#ifndef __QNX__
int digittoint_l(int c, locale_t loc);
int isideogram_l(int c, locale_t loc);
int isphonogram_l(int c, locale_t loc);
int isspecial_l(int c, locale_t loc);
#endif

#ifdef __cplusplus
}
#endif

#endif // QNX_XLOCALE_CTYPE_H
