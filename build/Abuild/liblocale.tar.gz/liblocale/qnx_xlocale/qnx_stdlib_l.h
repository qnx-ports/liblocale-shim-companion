#ifndef QNX_XLOCALE_STDLIB_H
#define QNX_XLOCALE_STDLIB_H

#include <stdlib.h>
#include <inttypes.h>
#include "qnx_xlocale.h"

#ifdef __cplusplus
extern "C"
{
#endif

double atof_l(const char* nptr, locale_t loc);
int atoi_l(const char* nptr, locale_t loc);
long atol_l(const char* nptr, locale_t loc);
long long atoll_l(const char* nptr, locale_t loc);

int mblen_l(const char* mbchar, size_t nbytes, locale_t locale);
size_t mbstowcs_l(wchar_t* wcstring, const char* mbstring, size_t nwchars, locale_t locale);
int mbtowc_l(wchar_t* wcharp, const char* mbchar, size_t nbytes, locale_t locale);

float strtof_l(const char* __restrict nptr, char** __restrict endptr, locale_t locale);
double strtod_l(const char* __restrict nptr, char** __restrict endptr, locale_t locale);
long double strtold_l(const char* __restrict nptr, char** __restrict endptr, locale_t locale);

long strtol_l(const char* __restrict nptr, char** __restrict endptr, int base, locale_t locale);
long long strtoll_l(const char* __restrict nptr, char** __restrict endptr, int base, locale_t locale);
unsigned long strtoul_l(const char* __restrict nptr, char** __restrict endptr, int base, locale_t locale);
unsigned long long strtoull_l(const char* __restrict nptr, char** __restrict endptr, int base, locale_t locale);

int wctomb_l(char* mbchar, wchar_t wchar, locale_t locale);
size_t wcstombs_l(char* mbstring, const wchar_t* wcstring, size_t nbytes, locale_t locale);

#ifdef __cplusplus
}
#endif

#endif // QNX_XLOCALE_STDLIB_H
