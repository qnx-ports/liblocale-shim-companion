#ifndef QNX_XLOCALE_QNX_XLOCALE_H
#define QNX_XLOCALE_QNX_XLOCALE_H

#include <stddef.h>

// https://man.freebsd.org/cgi/man.cgi?query=xlocale&sektion=3&format=html
#include "qnx_locale.h"


#ifdef __cplusplus
extern "C"
{
#endif

// Unsupported on QNX
#ifndef __QNX__
// <monetary.h>
ssize_t strfmon_l(char* restrict s, size_t maxsize, locale_t loc, const char* restrict format, ...);
#endif

#ifdef __cplusplus
}
#endif

#endif // QNX_XLOCALE_QNX_XLOCALE_H
