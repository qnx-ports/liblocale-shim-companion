#ifndef QNX_XLOCALE_INTTYPES_H
#define QNX_XLOCALE_INTTYPES_H

#include <inttypes.h>
#include "qnx_xlocale.h"

#ifdef __cplusplus
extern "C" {
#endif

intmax_t strtoimax_l(const char* __restrict __s, char** __restrict __endptr, int __base, locale_t locale);
intmax_t wcstoimax_l(const wchar_t* __restrict s, wchar_t** __restrict __endptr, int __base, locale_t locale);
uintmax_t strtoumax_l(const char* __restrict __s, char** __restrict __endptr, int __base, locale_t locale);
uintmax_t wcstoumax_l(const wchar_t* __restrict s, wchar_t** __restrict __endptr, int __base, locale_t locale);

#ifdef __cplusplus
}
#endif

#endif // QNX_XLOCALE_INTTYPES_H
