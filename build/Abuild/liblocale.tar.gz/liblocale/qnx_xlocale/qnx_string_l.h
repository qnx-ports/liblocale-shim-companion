#ifndef QNX_XLOCALE_STRING_H
#define QNX_XLOCALE_STRING_H

#include <string.h>
#include "qnx_xlocale.h"

#ifdef __cplusplus
extern "C" {
#endif

int strcoll_l(const char* s1, const char* s2, locale_t locale);
size_t strxfrm_l(char* dst, const char* src, size_t n, locale_t loc);
int strcasecmp_l(const char* s1, const char* s2, locale_t locale);
int strncasecmp_l(const char* s1, const char* s2, size_t len, locale_t locale);
char* strcasestr_l(const char* big, const char* little, locale_t loc);

#ifdef __cplusplus
}
#endif

#endif // QNX_XLOCALE_STRING_H
