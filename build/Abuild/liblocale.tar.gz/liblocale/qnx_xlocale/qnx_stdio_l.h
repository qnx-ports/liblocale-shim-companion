#ifndef QNX_XLOCALE_STDIO_H
#define QNX_XLOCALE_STDIO_H

#include <stdio.h>
#include <stdarg.h>
#include "qnx_xlocale.h"

#ifdef __cplusplus
extern "C" {
#endif

int printf_l(locale_t loc, const char* format, ...);
int asprintf_l(char** ret, locale_t loc, const char* format, ...);
int fprintf_l(FILE* stream, locale_t loc, const char* format, ...);
int snprintf_l(char* str, size_t size, locale_t loc, const char* format, ...);
int sprintf_l(char* str, locale_t loc, const char* format, ...);
int vasprintf_l(char** ret, locale_t loc, const char* format, va_list ap);
int vfprintf_l(FILE* stream, locale_t loc, const char* format, va_list ap);
int vprintf_l(locale_t loc, const char* format, va_list ap);
int vsnprintf_l(char* str, size_t size, locale_t loc, const char* format, va_list ap);
int vsprintf_l(char* str, locale_t loc, const char* format, va_list ap);

int scanf_l(locale_t loc, const char* format, ...);
int fscanf_l(FILE* stream, locale_t loc, const char* format, ...);
int sscanf_l(const char* str, locale_t loc, const char* format, ...);
int vfscanf_l(FILE* stream, locale_t loc, const char* format, va_list ap);
int vscanf_l(locale_t loc, const char* format, va_list ap);
int vsscanf_l(const char* str, locale_t loc, const char* format, va_list ap);

#ifdef __cplusplus
}
#endif

#endif // QNX_XLOCALE_STDIO_H
