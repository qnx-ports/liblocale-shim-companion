#ifndef QNX_XLOCALE_WCHAR_H
#define QNX_XLOCALE_WCHAR_H

#include <wchar.h>
#include <stdarg.h>
#include <inttypes.h>
#include <uchar.h>
#include <wchar.h>
#include "qnx_xlocale.h"

#ifdef __cplusplus
extern "C" {
#endif

wint_t btowc_l(int c, locale_t loc);
int wctob_l(wint_t c, locale_t loc);
wint_t fgetwc_l(FILE* stream, locale_t locale);
wint_t getwc_l(FILE* stream, locale_t locale);
wint_t getwchar_l(locale_t locale);
wchar_t* fgetws_l(wchar_t* __restrict ws, int n, FILE* __restrict fp, locale_t locale);
wint_t fputwc_l(wchar_t wc, FILE* stream, locale_t locale);
wint_t putwc_l(wchar_t wc, FILE* stream, locale_t locale);
wint_t putwchar_l(wchar_t wc, locale_t locale);
int vfwprintf_l(FILE* __restrict stream, locale_t loc, const wchar_t* __restrict format, va_list ap);
int vswprintf_l(wchar_t* __restrict ws, size_t n, locale_t loc, const wchar_t* __restrict format, va_list ap);
int vwprintf_l(locale_t loc, const wchar_t* __restrict format, va_list ap);
int fwprintf_l(FILE* __restrict stream, locale_t loc, const wchar_t* __restrict format, ...);
int swprintf_l(wchar_t* __restrict ws, size_t n, locale_t loc, const wchar_t* __restrict format, ...);
int wprintf_l(locale_t loc, const wchar_t* __restrict format, ...);
int vwscanf_l(locale_t loc, const wchar_t* __restrict format, va_list ap);
int vswscanf_l(const wchar_t* __restrict str, locale_t loc, const wchar_t* __restrict format, va_list ap);
int vfwscanf_l(FILE* __restrict stream, locale_t loc, const wchar_t* __restrict format, va_list ap);
int wscanf_l(locale_t loc, const wchar_t* __restrict format, ...);
int fwscanf_l(FILE* __restrict stream, locale_t loc, const wchar_t* __restrict format, ...);
int swscanf_l(const wchar_t* __restrict str, locale_t loc, const wchar_t* __restrict format, ...);
size_t mbrlen_l(const char* __restrict s, size_t n, mbstate_t* __restrict ps, locale_t locale);
size_t mbrtowc_l(wchar_t* __restrict pc, const char* __restrict s, size_t n, mbstate_t* __restrict ps, locale_t locale);
size_t mbrtoc16_l(char16_t* __restrict pc, const char* __restrict s, size_t n, mbstate_t* __restrict ps,
                  locale_t locale);
size_t mbrtoc32_l(char32_t* __restrict pc, const char* __restrict s, size_t n, mbstate_t* __restrict ps,
                  locale_t locale);
int mbsinit_l(const mbstate_t* ps, locale_t locale);
size_t mbsrtowcs_l(wchar_t* __restrict dst, const char** __restrict src, size_t len, mbstate_t* __restrict ps,
                   locale_t locale);
wint_t ungetwc_l(wint_t wc, FILE* stream, locale_t locale);
size_t wcrtomb_l(char* __restrict s, wchar_t c, mbstate_t* __restrict ps, locale_t locale);
size_t c16rtomb_l(char* __restrict s, char16_t c, mbstate_t* __restrict ps, locale_t locale);
size_t c32rtomb_l(char* __restrict s, char32_t c, mbstate_t* __restrict ps, locale_t);
int wcscoll_l(const wchar_t* s1, const wchar_t* s2, locale_t locale);
size_t wcsftime_l(wchar_t* __restrict wcs, size_t maxsize, const wchar_t* __restrict format,
                  const struct tm* __restrict timeptr, locale_t locale);
size_t wcsrtombs_l(char* __restrict dst, const wchar_t** __restrict src, size_t len, mbstate_t* __restrict ps,
                 locale_t locale);
float wcstof_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, locale_t locale);
long double wcstold_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, locale_t locale);
double wcstod_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, locale_t locale);
long wcstol_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, int base, locale_t locale);
unsigned long wcstoul_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, int base, locale_t locale);
long long wcstoll_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, int base, locale_t locale);
unsigned long long wcstoull_l(const wchar_t* __restrict nptr, wchar_t** __restrict endptr, int base, locale_t locale);
size_t wcsxfrm_l(wchar_t* __restrict dst, const wchar_t* __restrict src, size_t n, locale_t locale);
int wcwidth_l(wchar_t wc, locale_t locale);

size_t mbsnrtowcs_l(wchar_t* __restrict dst, const char** __restrict src, size_t nms, size_t len,
                    mbstate_t* __restrict ps, locale_t locale);
size_t wcsnrtombs_l(char* __restrict dst, const wchar_t** __restrict src, size_t nwc, size_t len,
                    mbstate_t* __restrict ps, locale_t locale);
int wcswidth_l(const wchar_t* pwcs, size_t n, locale_t locale);

#ifdef __cplusplus
}
#endif

#endif // QNX_XLOCALE_WCHAR_H
