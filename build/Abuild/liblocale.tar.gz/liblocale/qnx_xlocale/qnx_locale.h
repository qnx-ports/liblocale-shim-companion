#ifndef QNX_XLOCALE_QNX_LOCALE_H
#define QNX_XLOCALE_QNX_LOCALE_H
#define _LOCALE_H_DECLARED

#ifndef __PLATFORM_H_INCLUDED
#include <sys/platform.h>
#endif

#ifndef NULL
# define NULL _NULL
#endif


#ifdef __cplusplus
extern "C" {
#endif

        /* locale category indexes */
#define _LC_COLLATE		1
#define _LC_CTYPE		2
#define _LC_MONETARY	3
#define _LC_NUMERIC		4
#define _LC_TIME		5
#define _LC_MESSAGES	6
    /* ADD YOURS HERE, THEN UPDATE _NCAT */
#define _NCAT			7	/* one more than last index */

        /* locale category masks */
#define _CATMASK(n)	((1 << (n)) >> 1)
#define _M_COLLATE	_CATMASK(_LC_COLLATE)
#define _M_CTYPE	_CATMASK(_LC_CTYPE)
#define _M_MONETARY	_CATMASK(_LC_MONETARY)
#define _M_NUMERIC	_CATMASK(_LC_NUMERIC)
#define _M_TIME		_CATMASK(_LC_TIME)
#define _M_MESSAGES	_CATMASK(_LC_MESSAGES)
#define _M_ALL		(_CATMASK(_NCAT) - 1)

        /* locale category handles */
#define LC_COLLATE	_CATMASK(_LC_COLLATE)
#define LC_CTYPE	_CATMASK(_LC_CTYPE)
#define LC_MONETARY	_CATMASK(_LC_MONETARY)
#define LC_NUMERIC	_CATMASK(_LC_NUMERIC)
#define LC_TIME		_CATMASK(_LC_TIME)
#define LC_MESSAGES	_CATMASK(_LC_MESSAGES)
#define LC_ALL		(_CATMASK(_NCAT) - 1)

        /* locale category masks */
#define LC_COLLATE_MASK  _M_COLLATE
#define LC_CTYPE_MASK    _M_CTYPE
#define LC_MONETARY_MASK _M_MONETARY
#define LC_NUMERIC_MASK  _M_NUMERIC
#define LC_TIME_MASK     _M_TIME
#define LC_MESSAGES_MASK _M_MESSAGES
#define LC_ALL_MASK      _M_ALL

struct lconv
        {	/* locale-specific information */
                /* controlled by LC_MONETARY */
        char *currency_symbol;
        char *int_curr_symbol;
        char *mon_decimal_point;
        char *mon_grouping;
        char *mon_thousands_sep;
        char *negative_sign;
        char *positive_sign;
        char frac_digits;
        char int_frac_digits;
        char n_cs_precedes;
        char n_sep_by_space;
        char n_sign_posn;
        char p_cs_precedes;
        char p_sep_by_space;
        char p_sign_posn;

        char int_n_cs_precedes;	/* Added with C99 */
        char int_n_sep_by_space;	/* Added with C99 */
        char int_n_sign_posn;		/* Added with C99 */
        char int_p_cs_precedes;	/* Added with C99 */
        char int_p_sep_by_space;	/* Added with C99 */
        char int_p_sign_posn;		/* Added with C99 */

                /* controlled by LC_NUMERIC */
        char *decimal_point;
        char *grouping;
        char *thousands_sep;
        char *_Frac_grouping;
        char *_Frac_sep;
        char *_False;
        char *_True;

                /* controlled by LC_MESSAGES */
        char *_No;
        char *_Yes;
        char *_Nostr;
        char *_Yesstr;
        char *_Reserved[8];
        };

struct _Linfo;

typedef const char* locale_t;
// https://pubs.opengroup.org/onlinepubs/9699919799.2013edition/functions/uselocale.html
#define LC_GLOBAL_LOCALE ((locale_t)(~(uint64_t)0))
/* multibyte current max */
#define MB_CUR_MAX_L(loc) MB_CUR_MAX

struct lconv *localeconv(void);
char *setlocale(int __category, const char* __locale);
locale_t newlocale(int mask, const char* locale, locale_t base);
void freelocale(locale_t locale);
locale_t uselocale(locale_t locale);
struct lconv* localeconv_l(locale_t locale);
extern struct lconv _Locale;

#ifdef __cplusplus
}
#endif

#endif // QNX_XLOCALE_QNX_LOCALE_H
