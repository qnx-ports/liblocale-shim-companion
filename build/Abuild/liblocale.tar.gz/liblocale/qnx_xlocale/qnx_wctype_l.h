#ifndef QNX_XLOCALE_WCTYPE_H
#define QNX_XLOCALE_WCTYPE_H

#include <wctype.h>
#include "qnx_xlocale.h"

#ifdef __cplusplus
extern "C" {
#endif

int iswalnum_l(wint_t wc, locale_t loc);
int iswalpha_l(wint_t wc, locale_t loc);
int iswcntrl_l(wint_t wc, locale_t loc);
int iswdigit_l(wint_t wc, locale_t loc);
int iswgraph_l(wint_t wc, locale_t loc);
int iswlower_l(wint_t wc, locale_t loc);
int iswprint_l(wint_t wc, locale_t loc);
int iswpunct_l(wint_t wc, locale_t loc);
int iswspace_l(wint_t wc, locale_t loc);
int iswupper_l(wint_t wc, locale_t loc);
int iswxdigit_l(wint_t wc, locale_t loc);
int iswblank_l(wint_t wc, locale_t loc);
int iswhexnumber_l(wint_t wc, locale_t loc);
int iswnumber_l(wint_t wc, locale_t loc);
int iswrune_l(wint_t wc, locale_t loc); // alias of isacii()
wint_t towlower_l(wint_t wc, locale_t loc);
wint_t towupper_l(wint_t wc, locale_t loc);
wint_t towctrans_l(wint_t wc, wctrans_t desc, locale_t loc);
wctrans_t wctrans_l(const char* charclass, locale_t loc);
int iswctype_l(wint_t wc, wctype_t desc, locale_t loc);
wctype_t wctype_l(const char* property, locale_t loc);

// Unsupported on QNX
#ifndef __QNX__
int iswideogram_l(wint_t wc, locale_t loc);
int iswphonogram_l(wint_t wc, locale_t loc);
int iswspecial_l(wint_t wc, locale_t loc);
wint_t nextwctype_l(wint_t wc, locale_t loc);
#endif

#ifdef __cplusplus
}
#endif

#endif // QNX_XLOCALE_WCTYPE_H
